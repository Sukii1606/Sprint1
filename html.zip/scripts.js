// scripts.js

function redirectToHome(e) {
  e.preventDefault();
  let password = e.target.password.value;
  let confirmPassword = e.target.confirm_password.value;

  if (password !== confirmPassword) {
    alert("Passwords do not match. Please try again.");
    return;
  }
  // Proceed with form submission
  window.location.href = "home.html";
}
